
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/components/ui/use-toast";
import MainLayout from "@/layouts/MainLayout";
import { AlertTriangle, CheckCircle, MessageSquare } from "lucide-react";

const Complaints = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [computerNumber, setComputerNumber] = useState("");
  const [issueType, setIssueType] = useState("");
  const [priority, setPriority] = useState("medium");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  
  const { toast } = useToast();
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate form submission
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
      
      toast({
        title: "Complaint submitted",
        description: "Your issue has been reported and will be addressed soon.",
      });
      
      // Clear form after submission
      setName("");
      setEmail("");
      setComputerNumber("");
      setIssueType("");
      setPriority("medium");
      setDescription("");
    }, 1000);
  };
  
  const resetForm = () => {
    setSubmitted(false);
  };

  return (
    <MainLayout>
      <div className="py-12 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold">Report an Issue</h1>
          <p className="mt-2 text-gray-600">
            Submit a complaint or report a technical problem with the lab computers
          </p>
        </div>
        
        {submitted ? (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-center mb-4">
                <CheckCircle className="h-16 w-16 text-green-500" />
              </div>
              <CardTitle className="text-2xl text-center">Thank You!</CardTitle>
              <CardDescription className="text-center">
                Your complaint has been submitted successfully.
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <p className="mb-4">
                Your issue has been reported and assigned a ticket number. A lab administrator will review your complaint shortly.
              </p>
              <p className="text-sm text-gray-500">
                For urgent issues, please contact the lab administrator directly.
              </p>
            </CardContent>
            <CardFooter className="flex justify-center">
              <Button onClick={resetForm}>Submit Another Complaint</Button>
            </CardFooter>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MessageSquare className="mr-2 h-5 w-5" />
                Complaint Form
              </CardTitle>
              <CardDescription>
                Please provide details about the issue you're experiencing
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input 
                      id="name" 
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Your name"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input 
                      id="email" 
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="your.email@example.com"
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="computerNumber">Computer Number</Label>
                    <Input 
                      id="computerNumber" 
                      value={computerNumber}
                      onChange={(e) => setComputerNumber(e.target.value)}
                      placeholder="e.g. PC-12"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="issueType">Type of Issue</Label>
                    <Select value={issueType} onValueChange={setIssueType} required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select issue type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hardware">Hardware Problem</SelectItem>
                        <SelectItem value="software">Software Problem</SelectItem>
                        <SelectItem value="network">Network Issue</SelectItem>
                        <SelectItem value="peripheral">Peripheral Device Issue</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Priority Level</Label>
                  <RadioGroup
                    value={priority}
                    onValueChange={setPriority}
                    className="flex space-x-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="low" id="low" />
                      <Label htmlFor="low" className="cursor-pointer">Low</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="medium" id="medium" />
                      <Label htmlFor="medium" className="cursor-pointer">Medium</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="high" id="high" />
                      <Label htmlFor="high" className="cursor-pointer">High</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Description of the Issue</Label>
                  <Textarea 
                    id="description" 
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Please describe the problem in detail..."
                    className="min-h-[120px]"
                    required
                  />
                </div>
                
                <div className="bg-amber-50 border border-amber-200 p-4 rounded-md flex items-start">
                  <AlertTriangle className="h-5 w-5 text-amber-500 mr-3 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-amber-800">
                    For critical issues that require immediate attention, please contact the lab administrator directly at 
                    <a href="tel:+1234567890" className="font-medium underline ml-1">
                      (123) 456-7890
                    </a>.
                  </p>
                </div>
                
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? "Submitting..." : "Submit Complaint"}
                </Button>
              </form>
            </CardContent>
          </Card>
        )}
      </div>
    </MainLayout>
  );
};

export default Complaints;
