
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import MainLayout from "@/layouts/MainLayout";
import { 
  Users, Computer, AlertCircle, CheckCircle, Clock,
  BarChart3, PieChart, CalendarDays, User
} from "lucide-react";
import { 
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, Legend, ResponsiveContainer, PieChart as RechartPieChart, 
  Pie, Cell
} from "recharts";

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState("overview");
  
  // Sample data for demonstration
  const usageData = [
    { name: "Mon", users: 65 },
    { name: "Tue", users: 82 },
    { name: "Wed", users: 73 },
    { name: "Thu", users: 55 },
    { name: "Fri", users: 70 },
    { name: "Sat", users: 34 },
    { name: "Sun", users: 28 },
  ];
  
  const issueData = [
    { name: "Hardware", value: 12 },
    { name: "Software", value: 24 },
    { name: "Network", value: 8 },
    { name: "Other", value: 5 },
  ];
  
  const COLORS = ["#9b87f5", "#6E59A5", "#1A1F2C", "#D6BCFA"];
  
  const recentComplaints = [
    {
      id: "C001",
      computer: "PC-05",
      issue: "Software crash when opening design applications",
      status: "pending",
      date: "2023-04-16",
    },
    {
      id: "C002",
      computer: "PC-12",
      issue: "Monitor displaying distorted colors",
      status: "in-progress",
      date: "2023-04-15",
    },
    {
      id: "C003",
      computer: "PC-08",
      issue: "Keyboard not responding",
      status: "resolved",
      date: "2023-04-14",
    },
    {
      id: "C004",
      computer: "PC-23",
      issue: "Slow performance and frequent freezing",
      status: "resolved",
      date: "2023-04-13",
    },
  ];
  
  const computers = [
    { id: "PC-01", status: "available", lastUser: "Emma Thompson", lastLogin: "2 hours ago" },
    { id: "PC-02", status: "in-use", lastUser: "James Wilson", lastLogin: "45 minutes ago" },
    { id: "PC-03", status: "maintenance", lastUser: "Olivia Martinez", lastLogin: "Yesterday" },
    { id: "PC-04", status: "available", lastUser: "Noah Garcia", lastLogin: "3 hours ago" },
    { id: "PC-05", status: "in-use", lastUser: "Sophia Rodriguez", lastLogin: "20 minutes ago" },
    { id: "PC-06", status: "available", lastUser: "William Brown", lastLogin: "1 hour ago" },
  ];
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">Pending</Badge>;
      case "in-progress":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">In Progress</Badge>;
      case "resolved":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Resolved</Badge>;
      case "available":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Available</Badge>;
      case "in-use":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">In Use</Badge>;
      case "maintenance":
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Maintenance</Badge>;
      default:
        return <Badge>Unknown</Badge>;
    }
  };

  return (
    <MainLayout>
      <div className="px-4 sm:px-6 lg:px-8 py-8 max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Lab Dashboard</h1>
            <p className="text-gray-600">Monitor lab usage and manage resources</p>
          </div>
          <div className="mt-4 sm:mt-0 flex space-x-3">
            <Button variant="outline" size="sm">
              <CalendarDays className="mr-2 h-4 w-4" />
              Generate Report
            </Button>
            <Button size="sm">
              <User className="mr-2 h-4 w-4" />
              Admin Settings
            </Button>
          </div>
        </div>
        
        {/* Overview Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Total Computers</p>
                  <h3 className="text-3xl font-bold mt-1">50</h3>
                </div>
                <div className="h-12 w-12 bg-primary/10 rounded-full flex items-center justify-center">
                  <Computer className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div className="mt-4">
                <p className="text-sm text-gray-500">6 need maintenance</p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Active Users</p>
                  <h3 className="text-3xl font-bold mt-1">23</h3>
                </div>
                <div className="h-12 w-12 bg-primary/10 rounded-full flex items-center justify-center">
                  <Users className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div className="mt-4">
                <p className="text-sm text-gray-500">46% occupancy rate</p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Open Complaints</p>
                  <h3 className="text-3xl font-bold mt-1">12</h3>
                </div>
                <div className="h-12 w-12 bg-primary/10 rounded-full flex items-center justify-center">
                  <AlertCircle className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div className="mt-4">
                <p className="text-sm text-gray-500">5 high priority</p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Lab Uptime</p>
                  <h3 className="text-3xl font-bold mt-1">99.2%</h3>
                </div>
                <div className="h-12 w-12 bg-primary/10 rounded-full flex items-center justify-center">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div className="mt-4">
                <p className="text-sm text-gray-500">Last 30 days</p>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 lg:w-auto">
            <TabsTrigger value="overview">
              <BarChart3 className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="computers">
              <Computer className="h-4 w-4 mr-2" />
              Computers
            </TabsTrigger>
            <TabsTrigger value="complaints">
              <AlertCircle className="h-4 w-4 mr-2" />
              Complaints
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Daily Lab Usage</CardTitle>
                  <CardDescription>Number of users per day this week</CardDescription>
                </CardHeader>
                <CardContent className="px-2">
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={usageData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="users"
                        stroke="#9b87f5"
                        activeDot={{ r: 8 }}
                        strokeWidth={2}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Issue Categories</CardTitle>
                  <CardDescription>Distribution of reported issues by type</CardDescription>
                </CardHeader>
                <CardContent className="flex justify-center">
                  <ResponsiveContainer width="100%" height={300}>
                    <RechartPieChart>
                      <Pie
                        data={issueData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {issueData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RechartPieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Resource Utilization</CardTitle>
                <CardDescription>Current usage of lab resources</CardDescription>
              </CardHeader>
              <CardContent className="space-y-8">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Computers</Label>
                    <span className="text-sm text-muted-foreground">68%</span>
                  </div>
                  <Progress value={68} />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Network Bandwidth</Label>
                    <span className="text-sm text-muted-foreground">45%</span>
                  </div>
                  <Progress value={45} />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Printer Queue</Label>
                    <span className="text-sm text-muted-foreground">12%</span>
                  </div>
                  <Progress value={12} />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="computers" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Computer Status</CardTitle>
                <CardDescription>Current status of all lab computers</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {computers.map((computer) => (
                    <div key={computer.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold">{computer.id}</h3>
                        {getStatusBadge(computer.status)}
                      </div>
                      <div className="space-y-1 text-sm">
                        <div className="flex items-center">
                          <User className="h-4 w-4 mr-2 text-gray-500" />
                          <span>{computer.lastUser}</span>
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-2 text-gray-500" />
                          <span>{computer.lastLogin}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Usage Analytics</CardTitle>
                <CardDescription>Computer usage by department</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={[
                      { name: "Computer Science", usage: 85 },
                      { name: "Engineering", usage: 65 },
                      { name: "Business", usage: 45 },
                      { name: "Arts", usage: 30 },
                      { name: "Sciences", usage: 55 },
                    ]}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="usage" fill="#6E59A5" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="complaints" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Complaints</CardTitle>
                <CardDescription>Latest issues reported by users</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentComplaints.map((complaint) => (
                    <div key={complaint.id} className="border rounded-lg p-4">
                      <div className="flex flex-wrap items-start justify-between mb-2">
                        <div className="flex items-center mb-2 sm:mb-0">
                          <span className="font-semibold mr-3">#{complaint.id}</span>
                          <span className="text-sm bg-gray-100 px-2 py-1 rounded">
                            {complaint.computer}
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-500">{complaint.date}</span>
                          {getStatusBadge(complaint.status)}
                        </div>
                      </div>
                      <p className="text-gray-700">{complaint.issue}</p>
                      <div className="mt-3 flex justify-end space-x-2">
                        <Button variant="outline" size="sm">Details</Button>
                        {complaint.status !== "resolved" && (
                          <Button size="sm">Resolve</Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Resolution Time</CardTitle>
                <CardDescription>Average time to resolve complaints by category</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={[
                      { name: "Hardware", time: 48 },
                      { name: "Software", time: 24 },
                      { name: "Network", time: 12 },
                      { name: "Peripheral", time: 8 },
                      { name: "Other", time: 36 },
                    ]}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis label={{ value: 'Hours', angle: -90, position: 'insideLeft' }} />
                    <Tooltip />
                    <Bar dataKey="time" fill="#9b87f5" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
};

interface LabelProps {
  className?: string;
  children: React.ReactNode;
}

const Label = ({ className, children }: LabelProps) => {
  return (
    <div className={className}>
      {children}
    </div>
  );
};

export default Dashboard;
