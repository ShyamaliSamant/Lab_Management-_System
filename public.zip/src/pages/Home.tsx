
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import MainLayout from "@/layouts/MainLayout";
import { Link } from "react-router-dom";
import { Computer, Clock, Users, CheckCircle, MousePointer, MessageCircle } from "lucide-react";

const Home = () => {
  const features = [
    {
      icon: <Computer className="h-10 w-10 text-primary" />,
      title: "50+ Computers",
      description: "Access to modern computers with the latest software",
    },
    {
      icon: <Clock className="h-10 w-10 text-primary" />,
      title: "Extended Hours",
      description: "Lab open from 8:00 AM to 10:00 PM on weekdays",
    },
    {
      icon: <Users className="h-10 w-10 text-primary" />,
      title: "Staff Support",
      description: "Knowledgeable staff available to assist with issues",
    },
    {
      icon: <CheckCircle className="h-10 w-10 text-primary" />,
      title: "Regular Maintenance",
      description: "All systems regularly updated and maintained",
    }
  ];

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="hero-gradient text-white">
        <div className="max-w-7xl mx-auto px-4 py-20 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">Computer Lab Management System</h1>
          <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-8">
            Streamlined access to computer resources and support services
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/login">
              <Button size="lg" variant="default" className="bg-white text-primary hover:bg-gray-100">
                Log In
              </Button>
            </Link>
            <Link to="/complaints">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                Report an Issue
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Lab Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="card-hover border-t-4 border-t-primary">
                <CardContent className="pt-6">
                  <div className="mb-4">{feature.icon}</div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-primary/10 text-primary mb-4">
                <MousePointer className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">1. Log In</h3>
              <p className="text-gray-600">Sign in with your institutional credentials to access the system</p>
            </div>
            
            <div className="text-center">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-primary/10 text-primary mb-4">
                <Computer className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">2. Use Resources</h3>
              <p className="text-gray-600">Access computers, software, and other lab resources</p>
            </div>
            
            <div className="text-center">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-primary/10 text-primary mb-4">
                <MessageCircle className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">3. Report Issues</h3>
              <p className="text-gray-600">Submit complaints or issues through the system for quick resolution</p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-primary/10">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl text-gray-600 mb-8">
            Log in now to access computer lab resources and services
          </p>
          <Link to="/login">
            <Button size="lg">Log In to System</Button>
          </Link>
        </div>
      </section>
    </MainLayout>
  );
};

export default Home;
